package com.example.project.DataBase;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.project.Model.CanWaterTable;
import com.example.project.Model.UserData;

import java.util.List;

@Dao
public interface UserDataDAO {
    @Query("SELECT * FROM user_data WHERE personId LIKE :id")
    List<UserData> getUserData(int id);

    @Query("SELECT numberOfUser FROM user_data WHERE orderId= :orderId")
    int getNumberOfUser(int orderId);

    @Query("SELECT favorite FROM user_data WHERE numberOfUser= :numberOfUser")
    int getPaticularStar(int numberOfUser);

    @Query("UPDATE user_data SET favorite = :status WHERE numberOfUser = :numberOfUser")
    void updateStar(int status, int numberOfUser);

    @Insert
    void insert(UserData userData);

    @Update
    void update(UserData userData);

    @Delete
    void delete(UserData userData);
}
