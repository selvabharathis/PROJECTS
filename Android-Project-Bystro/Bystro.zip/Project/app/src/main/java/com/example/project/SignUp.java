package com.example.project;


import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.example.project.DataBase.CanWater;
import com.example.project.DataBase.CanWaterDataBase;
import com.example.project.Model.CanWaterTable;

public class SignUp extends AppCompatActivity {
    private TextView signIn;
    private EditText name, email, password, repeatPassword;
    private Button createAccount;
    private CheckBox checkBox;
    private CanWater canWaterDao;
    private CheckBox passwordToggle,repeatPasswordToggle;
    private AwesomeValidation awesomeValidation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);
        signIn = findViewById(R.id.signInId);
        name = findViewById(R.id.nameEditText);
        email = findViewById(R.id.emailEditText);
        password = findViewById(R.id.passEditText);
        repeatPassword = findViewById(R.id.rpassEditText);
        createAccount = findViewById(R.id.signUpButton);
        checkBox = findViewById(R.id.checkBox);
        passwordToggle = findViewById(R.id.showPasswordCheckBox);
        repeatPasswordToggle = findViewById(R.id.showRepeatPasswordCheckBox);
        passwordToggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (!isChecked) {
                    // show password
                    password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                } else {
                    // hide password
                    password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });

        repeatPasswordToggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (!isChecked) {
                    // show password
                    repeatPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                } else {
                    // hide password
                    repeatPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });

        canWaterDao = Room.databaseBuilder(this, CanWaterDataBase.class, "myDatabase")
                .allowMainThreadQueries()
                .build()
                .getCanWaterDao();

        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToSignIn = new Intent(SignUp.this, MainActivity.class);
                startActivity(goToSignIn);
            }
        });
        String regexPassword = "(?=.*[a-z])(?=.*[A-Z])(?=.*[\\d])(?=.*[~`!@#\\$%\\^&\\*\\(\\)\\-_\\+=\\{\\}\\[\\]\\|\\;:\"<>,./\\?]).{8,}";
        awesomeValidation.addValidation(this,R.id.nameEditText,"^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$",R.string.nameError);
        awesomeValidation.addValidation(this,R.id.emailEditText, Patterns.EMAIL_ADDRESS,R.string.emailError);
        awesomeValidation.addValidation(this,R.id.passEditText,regexPassword,R.string.errorPass);
        awesomeValidation.addValidation(this,R.id.rpassEditText,R.id.passEditText,R.string.passMatchError);

        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (awesomeValidation.validate() && validate()) {
                    CanWaterTable user = canWaterDao.checkUserExistance(email.getText().toString());
                    if(user == null)
                    {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                CanWaterTable modelClassObj = new CanWaterTable(name.getText().toString(), email.getText().toString(),
                                        password.getText().toString());
                                canWaterDao.insert(modelClassObj);
                                startActivity(new Intent(SignUp.this, MainActivity.class));
                                finish();
                            }
                        }, 100);
                    }
                    else
                    {
                        Toast.makeText(SignUp.this,"you are already a member, login please",Toast.LENGTH_LONG).show();
                        startActivity(new Intent(SignUp.this, MainActivity.class));
                    }
                }
            }
        });
    }
    public boolean validate()
    {
        if(checkBox.isChecked())
            return true;
        else{
            Toast.makeText(SignUp.this,R.string.checkBoxError,Toast.LENGTH_SHORT).show();
            return false;
        }
    }
}