package com.example.project.ui.recent;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project.DataBase.CanWaterDataBase;
import com.example.project.DataBase.UserDataDAO;
import com.example.project.Model.UserData;
import com.example.project.R;
import com.example.project.RecentData;
import com.example.project.RecyclerAdapter;
import com.example.project.UserActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static com.example.project.MainActivity.MyPREFERENCES;

public class RecentFragment extends Fragment {

    private RecyclerAdapter recyclerAdapt;
    private RecyclerView recyclerView;
    private List<RecentData> list;
    private boolean select;
    private List<UserData> userArrayObj;
    SharedPreferences sharedpreferences;
    private UserDataDAO userDataDAO;
    int OC,RC,cost,OID,favorite;
    String DT,CWN,date,address;
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_recent, container, false);
        setHasOptionsMenu(true);
        recyclerView  = root.findViewById(R.id.recyclerViewRecent);
        LinearLayoutManager layoutMang = new LinearLayoutManager(getContext());
        layoutMang.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutMang);
        list = new ArrayList<>();
//        list = getData();
        sharedpreferences = this.getActivity().getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        int userId = sharedpreferences.getInt("userId", 0);

        CanWaterDataBase appDB = CanWaterDataBase.getInstance(this.getContext());
        userDataDAO = appDB.getUserDataDao();
        userArrayObj = new ArrayList<>();
        userArrayObj = userDataDAO.getUserData(userId);
        recyclerAdapt = new RecyclerAdapter(list,getContext(),userDataDAO);
        recyclerView.setAdapter(recyclerAdapt);
        for(int i=0;i<userArrayObj.size();i++){
           OID = userArrayObj.get(i).getOrderId();
           date = userArrayObj.get(i).getDate();
           OC = userArrayObj.get(i).getOrderQuantity();
           RC = userArrayObj.get(i).getReturnQuantity();
           DT =  userArrayObj.get(i).getDeliveryType();
           CWN =  userArrayObj.get(i).getCanWaterName();
           cost = userArrayObj.get(i).getCost();
           favorite = userArrayObj.get(i).getFavorite();
           address = userArrayObj.get(i).getAddress();
            if(favorite == 1)
                select = true;
            else
                select = false;
           RecentData data = new RecentData(OID,OC,RC,cost,DT,date,CWN,select,address);
           list.add(list.size(), data);
           recyclerAdapt.notifyDataSetChanged();
        }
        return root;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.sort, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.thirtyDays:
//                Toast.makeText(getActivity(),"last 30 days",Toast.LENGTH_SHORT).show();
                //ascending sort
                /*ArrayList<RecentData> tempListA= new ArrayList<>();
                Collections.copy(tempListA,list);*/
                Collections.sort(list, new Comparator<RecentData>() {
                    @Override
                    public int compare(RecentData o1, RecentData o2) {
                        return Integer.valueOf(o1.getOrderId()).compareTo(o2.getOrderId());
                    }
                });
                recyclerAdapt.sortedList(list);
                break;
            case R.id.sixMonths:
//                Toast.makeText(getActivity(),"last 6 months",Toast.LENGTH_SHORT).show();
                //decending sort
               /* ArrayList<RecentData> tempListD= new ArrayList<>();
                Collections.copy(tempListD,list);*/
                Collections.sort(list, new Comparator<RecentData>() {
                    @Override
                    public int compare(RecentData o1, RecentData o2) {
                        return Integer.valueOf(o2.getOrderId()).compareTo(o1.getOrderId());
                    }
                });
                recyclerAdapt.sortedList(list);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private List<RecentData> getData()
    {
        List<RecentData> list = new ArrayList<>();
//        list.add(new RecentData(101,1,1,90,"normal","1/1/20","Aqua Gold"));
//        list.add(new RecentData(101,1,1,90,"normal","1/1/20","Aqua Gold"));
        return list;
    }
}