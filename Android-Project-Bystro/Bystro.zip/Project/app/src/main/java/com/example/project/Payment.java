package com.example.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Payment extends AppCompatActivity {
    String canWaterName,totalCost,orderCount,returnCount,deliveryType;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        Toolbar toolbar = findViewById(R.id.myToolBar);
        Button placeOrder = findViewById(R.id.placeOrderId);
        TextView cost = findViewById(R.id.costId);
        final EditText address = findViewById(R.id.addressEditTextId);
        setTitle("Payment");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Intent intent = getIntent();
        totalCost = intent.getStringExtra("totalCost");
        orderCount = intent.getStringExtra("orderQuantity");
        returnCount = intent.getStringExtra("emptyCan");
        deliveryType = intent.getStringExtra("deliveryType");
        canWaterName = intent.getStringExtra("waterCanName");
        cost.setText(totalCost);
        placeOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(address.getText().toString().equals("")){
                    Toast.makeText(Payment.this,"please fill the address",Toast.LENGTH_LONG).show();
                }
                else{
                    Intent goToOrderConfirm = new Intent(Payment.this,OrderConformation.class);
                    goToOrderConfirm.putExtra("waterCanName",canWaterName);
                    goToOrderConfirm.putExtra("orderQuantity",orderCount);
                    goToOrderConfirm.putExtra("address",address.getText().toString());
                    goToOrderConfirm.putExtra("emptyCan",returnCount);
                    goToOrderConfirm.putExtra("deliveryType",deliveryType);
                    goToOrderConfirm.putExtra("totalCost",totalCost);
                    startActivity(goToOrderConfirm);
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == android.R.id.home ){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
