package com.example.project.DataBase;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.project.Model.CanWaterTable;
import com.example.project.Model.UserData;

@Database(entities = {CanWaterTable.class,UserData.class},version = 1,exportSchema = false)
public abstract class CanWaterDataBase extends RoomDatabase {
    private static final String DB_Name = "myDatabase";
    private static CanWaterDataBase instance;

    public abstract CanWater getCanWaterDao();
    public abstract UserDataDAO getUserDataDao();

    /*static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            // Since we didn't alter the table, there's nothing else to do here.
        }
    };*/

    public static synchronized CanWaterDataBase getInstance(Context context)
    {
        if(instance == null)
        {
            instance = Room.databaseBuilder(context.getApplicationContext(),CanWaterDataBase.class,DB_Name)
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return instance;
    }
}
