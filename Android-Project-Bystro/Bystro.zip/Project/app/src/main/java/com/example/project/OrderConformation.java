package com.example.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.room.Room;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project.DataBase.CanWater;
import com.example.project.DataBase.CanWaterDataBase;
import com.example.project.DataBase.UserDataDAO;
import com.example.project.Model.UserData;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

import static com.example.project.MainActivity.MyPREFERENCES;

public class OrderConformation extends AppCompatActivity {
    private TextView canWaterName,orderCount,returnCount,deliveryType,totalcost,date,orderId,addressText;
    static int orderID=1000;
    int oId,orderC,emptyC,cost,favorite;
    String dType,d,canWater,address;
    CheckBox favoriteCheckBox;
    SharedPreferences sharedpreferences;

    private UserDataDAO userDataDAO;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_conformation);
        Toolbar toolbar = findViewById(R.id.myToolBar);
        Button goToHome = findViewById(R.id.goToHomeButtonId);
        favoriteCheckBox = findViewById(R.id.favoriteCheckBox);
        canWaterName = findViewById(R.id.canWater);
        orderCount = findViewById(R.id.orderCount);
        returnCount = findViewById(R.id.returnCount);
        deliveryType = findViewById(R.id.deliveryType);
        totalcost = findViewById(R.id.totalCost);
        date = findViewById(R.id.dateTextView);
        orderId = findViewById(R.id.orderId);
        addressText = findViewById(R.id.addressTextView);
        orderId.setText(String.valueOf(orderID));

        String currentDate = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        date.setText(currentDate);
        setTitle("Order Confimation");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Intent intent = getIntent();
        canWaterName.setText(intent.getStringExtra("waterCanName"));
        orderCount.setText(intent.getStringExtra("orderQuantity"));
        returnCount.setText( intent.getStringExtra("emptyCan"));
        deliveryType.setText(intent.getStringExtra("deliveryType"));
        totalcost.setText(intent.getStringExtra("totalCost"));
        addressText.setText(intent.getStringExtra("address"));

        oId = orderID;
        orderID++;
        orderC = Integer.parseInt(intent.getStringExtra("orderQuantity"));
        emptyC = Integer.parseInt(intent.getStringExtra("emptyCan"));
        cost = Integer.parseInt(intent.getStringExtra("totalCost"));
        dType = intent.getStringExtra("deliveryType");
        d = currentDate;
        canWater = intent.getStringExtra("waterCanName");
        address = intent.getStringExtra("address");

        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        final int userId = sharedpreferences.getInt("userId", 0);

        CanWaterDataBase appDB = CanWaterDataBase.getInstance(this);
        userDataDAO = appDB.getUserDataDao();


        goToHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(favoriteCheckBox.isChecked())
                    favorite = 1;
                else
                    favorite = 0;
                UserData modelClassObj = new UserData(userId,oId,orderC,emptyC,dType,d,cost,canWater,favorite,address);
                userDataDAO.insert(modelClassObj);
                Intent goToHome = new Intent(OrderConformation.this,UserActivity.class);
                startActivity(goToHome);
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == android.R.id.home ){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
