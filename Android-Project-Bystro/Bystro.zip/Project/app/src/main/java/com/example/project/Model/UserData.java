package com.example.project.Model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName = "user_data")
public class UserData{

    @PrimaryKey(autoGenerate = true)
    private int numberOfUser;
    @ColumnInfo(name = "orderId")
    private int orderId;
    @ColumnInfo(name = "personId")
    private int personId;
    @ColumnInfo(name = "orderQuantity")
    private int orderQuantity;
    @ColumnInfo(name = "returnQuantity")
    private int returnQuantity;
    @ColumnInfo(name = "deliveryType")
    private String deliveryType;
    @ColumnInfo(name = "date")
    private String date;
    @ColumnInfo(name = "cost")
    private  int cost;
    @ColumnInfo(name = "canWaterName")
    private String canWaterName;
    @ColumnInfo(name = "favorite")
    private int favorite;
    @ColumnInfo(name = "address")
    private String address;


    public UserData(int personId,int orderId,int orderQuantity,int returnQuantity,String deliveryType,String date,int cost,String canWaterName,int favorite,String address){
        this.personId = personId;
        this.orderId = orderId;
        this.orderQuantity = orderQuantity;
        this.returnQuantity = returnQuantity;
        this.deliveryType = deliveryType;
        this.date = date;
        this.cost = cost;
        this.address = address;
        this.canWaterName = canWaterName;
        this.favorite = favorite;
    }

    public int getNumberOfUser() {
        return numberOfUser;
    }

    public void setNumberOfUser(int numberOfUser) {
        this.numberOfUser = numberOfUser;
    }
    public int getPersonId() {
        return personId;
    }

    public void setPersonId(int personId) {
        this.personId = personId;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getOrderQuantity() {
        return orderQuantity;
    }

    public void setOrderQuantity(int orderQuantity) {
        this.orderQuantity = orderQuantity;
    }

    public int getReturnQuantity() {
        return returnQuantity;
    }

    public void setReturnQuantity(int returnQuantity) {
        this.returnQuantity = returnQuantity;
    }

    public String getDeliveryType() {
        return deliveryType;
    }

    public void setDeliveryType(String deliveryType) {
        this.deliveryType = deliveryType;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public String getCanWaterName() {
        return canWaterName;
    }

    public void setCanWaterName(String canWaterName) {
        this.canWaterName = canWaterName;
    }

    public int getFavorite() {
        return favorite;
    }

    public void setFavorite(int favorite) {
        this.favorite = favorite;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}

