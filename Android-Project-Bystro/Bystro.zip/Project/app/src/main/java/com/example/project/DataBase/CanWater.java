package com.example.project.DataBase;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.project.Model.CanWaterTable;

// Data Access Object
@Dao
public interface CanWater {
    @Query("select * from can_water where email= :email and password= :password")
    CanWaterTable getUser(String email, String password);

    @Query("SELECT * FROM can_water WHERE email LIKE :email")
    CanWaterTable checkUserExistance(String email);

    @Query("SELECT name FROM can_water WHERE email= :email")
    String getUserName(String email);

    @Query("SELECT personId FROM can_water WHERE email= :email")
    int getUserId(String email);

    @Insert
    void insert(CanWaterTable user);

    @Update
    void update(CanWaterTable user);

    @Delete
    void delete(CanWaterTable user);
}
