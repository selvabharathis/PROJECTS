package com.example.project;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.example.project.DataBase.CanWater;
import com.example.project.DataBase.CanWaterDataBase;
import com.example.project.Model.CanWaterTable;

public class MainActivity extends AppCompatActivity {
    private TextView signUp;
    private Button signIn;
    private EditText email,password;
    private CanWater canWaterDao;
    private CheckBox passwordToggle;
    public static final String MyPREFERENCES = "MyPrefs" ;
    SharedPreferences sharedpreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        String restoredText = sharedpreferences.getString("email", null);
        if(restoredText != null){
            Intent justGoIn = new Intent(MainActivity.this,UserActivity.class);
            justGoIn.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(justGoIn);
        }


        CanWaterDataBase appDB = CanWaterDataBase.getInstance(this);
        canWaterDao = appDB.getCanWaterDao();

        signIn =  findViewById(R.id.sign_in);
        signUp = findViewById(R.id.signUpId);
        email = findViewById(R.id.nameEditText);
        password = findViewById(R.id.passwordEditText);
        passwordToggle = findViewById(R.id.showPasswordCheckBox);

        passwordToggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (!isChecked) {
                    // show password
                    password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                } else {
                    // hide password
                    password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToSignUp = new Intent(MainActivity.this,SignUp.class);
                startActivity(goToSignUp);
            }
        });

        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!emptyValidation()){
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            CanWaterTable user = canWaterDao.getUser(email.getText().toString(),password.getText().toString());
                            if(user != null){
                                String name = canWaterDao.getUserName(email.getText().toString());// user.getName();
                                int userId = canWaterDao.getUserId(email.getText().toString());
                                SharedPreferences.Editor editor = sharedpreferences.edit();
                                editor.putString("email",email.getText().toString());
                                editor.putString("name",name);
                                editor.putInt("userId",userId);
                                editor.apply();
                                Intent goToHomePage = new Intent(MainActivity.this,UserActivity.class);
                                goToHomePage.putExtra("userName",name);
                                goToHomePage.putExtra("email",email.getText().toString());
                                goToHomePage.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(goToHomePage);
                            }
                            else{
                                Toast.makeText(MainActivity.this,"you are not a member, sign up please",Toast.LENGTH_LONG).show();
                            }
                        }
                    },100);
                }
                else{
                    Toast.makeText(MainActivity.this,"all fields should be entered",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean emptyValidation(){
        if(TextUtils.isEmpty(email.getText().toString()) || TextUtils.isEmpty(password.getText().toString())){
            return true;
        }
        else{
            return false;
        }
    }
}


