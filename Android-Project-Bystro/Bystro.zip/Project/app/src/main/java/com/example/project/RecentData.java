package com.example.project;

public class RecentData {
    int orderC,emptyC,cost;
    int orderId;
    String deliveryType,date,canWaterName,address;
    private boolean isSelected;
    public RecentData(int orderId,int orderC,int emptyC,int cost,String deliveryType,String date,String canWaterName,boolean isSelected,String address)
    {
        this.orderId = orderId;
        this.orderC = orderC;
        this.emptyC = emptyC;
        this.cost = cost;
        this.deliveryType = deliveryType;
        this.date = date;
        this.canWaterName = canWaterName;
        this.isSelected = isSelected;
        this.address = address;
    }
    public void setSelected(boolean selected){
        isSelected = selected;
    }
    public boolean isSelected(){
        return isSelected;
    }
    public int getOrderId() {
        return orderId;
    }

}
