package com.example.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project.Fragments.Ingredients;
import com.example.project.Fragments.Nutrients;
import com.google.android.material.tabs.TabLayout;

public class OrderSummary extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private TextView canWaterName,canWaterPrice,orderCount,returnCount,cost,duration,note;
    private ImageView image;
    private Spinner spinnerSchedule,spin;
    private Button proceedToPayment,quantityPlus,quantityMinus,returnPlus,returnMinus;
    private TabLayout tabLayout;
    private int newCan = 150,singlePrice,flag=0,flagSpin=0;
    private String canWater;
    public PageAdapter pageAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_summary);
        Toolbar toolbar = findViewById(R.id.myToolBar);
        duration = findViewById(R.id.durationText);
        cost = findViewById(R.id.costId);
        note = findViewById(R.id.note);
        orderCount = findViewById(R.id.QuantityCountTextId);
        returnCount = findViewById(R.id.ReturnCountTextId);
        quantityPlus = findViewById(R.id.QuantityIncrementButton);
        quantityMinus = findViewById(R.id.QuantityDecrementButton);
        /*final Drawable quantityM = quantityMinus.getBackground();*/
        returnPlus = findViewById(R.id.ReturnIncrementButton);
        /*final Drawable returnP = returnPlus.getBackground();*/
        returnMinus = findViewById(R.id.ReturnDecrementButton);
        proceedToPayment = findViewById(R.id.PaymentButton);
        spin = findViewById(R.id.spinner);
        spin.setOnItemSelectedListener(this);
        spinnerSchedule = findViewById(R.id.spinner_schedule);
        setTitle("Order Summary");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        canWaterName = findViewById(R.id.canWaterNameOrder);
        canWaterPrice = findViewById(R.id.canWaterPriceOrder);
        image = findViewById(R.id.canWaterOrder);
        Intent intent = getIntent();
        canWater = intent.getStringExtra("name");
        canWaterName.setText(canWater);
        singlePrice = Integer.parseInt(intent.getStringExtra("price"));
        cost.setText(String.valueOf(singlePrice));
        canWaterPrice.setText(intent.getStringExtra("price"));
        image.setImageResource(intent.getIntExtra("image",0));

        tabLayout = findViewById(R.id.tabLayout);
        ViewPager viewPager = findViewById(R.id.viewPager);
        pageAdapter = new PageAdapter(getSupportFragmentManager(),tabLayout.getTabCount());
        Nutrients nutrients = new Nutrients();
        pageAdapter.addFragments(nutrients);
        pageAdapter.notifyDataSetChanged();
        Ingredients ingredients = new Ingredients();
        pageAdapter.addFragments(ingredients);
        pageAdapter.notifyDataSetChanged();
        viewPager.setAdapter(pageAdapter);
        tabLayout.setupWithViewPager(viewPager);

        quantityPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int tempOne = Integer.parseInt(orderCount.getText().toString());
               int count =   tempOne + 1 ;
               orderCount.setText(String.valueOf(count));
            }
        });

        quantityMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int count =  Integer.parseInt(orderCount.getText().toString());
                int temp = Integer.parseInt(returnCount.getText().toString());
                if(count != 0 && count != temp)
                {
                    orderCount.setText(String.valueOf(count-1));
                }
            }
        });

        returnPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int tempOne = Integer.parseInt(returnCount.getText().toString());
                int tempTwo = Integer.parseInt(orderCount.getText().toString());
                if(tempOne != tempTwo){
                    int count =  tempOne + 1 ;
                    returnCount.setText(String.valueOf(count));
                }
            }
        });

        returnMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int count =  Integer.parseInt(returnCount.getText().toString());
                if(count != 0)
                {
                    returnCount.setText(String.valueOf(count-1));
                }

            }
        });

        orderCount.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {}

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int tempOne = Integer.parseInt(orderCount.getText().toString());
                int tempTwo = Integer.parseInt(returnCount.getText().toString());
                if(tempOne == tempTwo){
                    returnPlus.setBackgroundResource(R.drawable.ic_plus_deactive);
                    quantityMinus.setBackgroundResource(R.drawable.ic_minus_deactive);
                }
                else if(tempOne == 0){
                    quantityMinus.setBackgroundResource(R.drawable.ic_minus_deactive);
                }
                else if(tempTwo == 0){
                    quantityMinus.setBackgroundResource(R.drawable.ic_minus_activate);
                    returnMinus.setBackgroundResource(R.drawable.ic_minus_deactive);
                    returnPlus.setBackgroundResource(R.drawable.ic_plus_active);
                }
                else if(tempOne > tempTwo){
                    quantityMinus.setBackgroundResource(R.drawable.ic_minus_activate);
                    returnPlus.setBackgroundResource(R.drawable.ic_plus_active);
                    returnMinus.setBackgroundResource(R.drawable.ic_minus_activate);
                }
                int orderC = Integer.parseInt(orderCount.getText().toString());
                int countC = Integer.parseInt(returnCount.getText().toString());
                int calc = (singlePrice * orderC) + (newCan * (orderC - countC));
                cost.setText(String.valueOf(calc));
            }
        });

        returnCount.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {}

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int tempOne = Integer.parseInt(orderCount.getText().toString());
                int tempTwo = Integer.parseInt(returnCount.getText().toString());
                if(tempOne == tempTwo){
                    quantityMinus.setBackgroundResource(R.drawable.ic_minus_deactive);
                    returnPlus.setBackgroundResource(R.drawable.ic_plus_deactive);
                    returnMinus.setBackgroundResource(R.drawable.ic_minus_activate);
                }
                else if(tempTwo == 0 && tempOne > tempTwo) {
                    returnMinus.setBackgroundResource(R.drawable.ic_minus_deactive);
                    quantityMinus.setBackgroundResource(R.drawable.ic_minus_activate);
                    returnPlus.setBackgroundResource(R.drawable.ic_plus_active);
                }
                else if(tempOne > tempTwo){
                    quantityMinus.setBackgroundResource(R.drawable.ic_minus_activate);
                    returnPlus.setBackgroundResource(R.drawable.ic_plus_active);
                    returnMinus.setBackgroundResource(R.drawable.ic_minus_activate);
                }
                int orderC = Integer.parseInt(orderCount.getText().toString());
                int countC = Integer.parseInt(returnCount.getText().toString());
                int calc = (singlePrice * orderC) + (newCan * (orderC - countC));
                cost.setText(String.valueOf(calc));
            }
        });




        createCustomTab();
        proceedToPayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(orderCount.getText().toString().equals("0")){
                    Toast.makeText(OrderSummary.this,"buy atleast 1 can to proceed",Toast.LENGTH_LONG).show();
                }
                else{
                    Intent proceedPayment = new Intent(OrderSummary.this,Payment.class);
                    proceedPayment.putExtra("waterCanName",canWater);
                    proceedPayment.putExtra("orderQuantity",orderCount.getText().toString());
                    proceedPayment.putExtra("emptyCan",returnCount.getText().toString());
                    proceedPayment.putExtra("deliveryType",spin.getSelectedItem().toString());
                    proceedPayment.putExtra("totalCost",cost.getText().toString());
                    startActivity(proceedPayment);
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == android.R.id.home ){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void createCustomTab()
    {
        TextView tabOne = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, null);
        tabOne.setCompoundDrawablesWithIntrinsicBounds(R.drawable.radio_focus,0, 0, 0);
        tabOne.setCompoundDrawablePadding(0);
        tabLayout.getTabAt(0).setCustomView(tabOne);

        TextView tabTwo = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, null);
        tabTwo.setCompoundDrawablesWithIntrinsicBounds(R.drawable.radio_focus,0, 0, 0);
        tabTwo.setCompoundDrawablePadding(0);
        tabLayout.getTabAt(1).setCustomView(tabTwo);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch(position){
            case 0:
                duration.setText("Within 3 hours");
                note.setText("");
                if(flag == 1){
                    cost.setText(String.valueOf(Integer.parseInt(cost.getText().toString()) - 20));
                    flag = 0;
                }
                if(flagSpin == 1){
                    spinnerSchedule.setVisibility(view.INVISIBLE);
                    flagSpin=0;
                }

                break;
            case 1:
                duration.setText("Within 30 minutes");
                cost.setText(String.valueOf(Integer.parseInt(cost.getText().toString()) + 20));
                flag = 1;
                if(flagSpin == 1){
                    spinnerSchedule.setVisibility(view.INVISIBLE);
                    flagSpin=0;
                }
                note.setText("Note: A sum of Rs 20 will be charged extra on every two cans for quick delivery");
                break;
            case 2:
                duration.setText("");
                note.setText("");
                spinnerSchedule.setVisibility(view.VISIBLE);
                flagSpin = 1;
                if(flag == 1){
                    cost.setText(String.valueOf(Integer.parseInt(cost.getText().toString()) - 20));
                    flag = 0;
                }
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
