package com.example.project;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.project.DataBase.UserDataDAO;
import com.example.project.Model.UserData;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder>
{
    private List<RecentData> list = Collections.emptyList();
    private Context context;
    private UserDataDAO userDataDAO;
    public RecyclerAdapter(List<RecentData> list, Context context,UserDataDAO userDataDAO)
    {
        this.list = list;
        this.context = context;
        this.userDataDAO = userDataDAO;
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View photoView = inflater.inflate(R.layout.recent_template,parent,false);
        ViewHolder viewHolder = new ViewHolder(photoView);
        return viewHolder;
    }
    @Override
    public void onBindViewHolder(final ViewHolder viewHolder,final int position)
    {
        final RecentData recentDataObj = list.get(position);
        viewHolder.orderId.setText(String.valueOf(list.get(position).orderId));
        viewHolder.date.setText(list.get(position).date);
        viewHolder.canwaterName.setText(list.get(position).canWaterName);
        viewHolder.orderCount.setText(String.valueOf(list.get(position).orderC));
        viewHolder.returnCount.setText(String.valueOf(list.get(position).emptyC));
        viewHolder.cost.setText(String.valueOf(list.get(position).cost));
        viewHolder.deliveryType.setText(list.get(position).deliveryType);
        viewHolder.address.setText(list.get(position).address);
        final int numberOfUser = userDataDAO.getNumberOfUser(Integer.parseInt(viewHolder.orderId.getText().toString()));
        if(userDataDAO.getPaticularStar(numberOfUser) == 1){//recentDataObj.isSelected()
            viewHolder.star.setBackgroundResource(R.drawable.ic_star_active);
        }
        else{
            viewHolder.star.setBackgroundResource(R.drawable.ic_star_deactive);
        }
    }
    @Override
    public int getItemCount()
    {
        return list.size();
    }
    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView)
    {
        super.onAttachedToRecyclerView(recyclerView);
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        private TextView orderId,date,orderCount,returnCount,deliveryType,canwaterName,cost,address;
        ImageView star;
        ViewHolder(final View itemView)
        {
            super(itemView);
            orderId = itemView.findViewById(R.id.orderRecentId);
            date = itemView.findViewById(R.id.dateTextViewRecentId);
            orderCount = itemView.findViewById(R.id.orderCountRecentId);
            returnCount = itemView.findViewById(R.id.returnCountRecentId);
            deliveryType = itemView.findViewById(R.id.deliveryTypeRecentId);
            canwaterName = itemView.findViewById(R.id.canWaterRecentId);
            cost = itemView.findViewById(R.id.totalCosRecentIdt);
            star = itemView.findViewById(R.id.favorite);
            address = itemView.findViewById(R.id.addressRecentTextView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    final RecentData recentDataObj = list.get(position);
                    final int numberOfUser = userDataDAO.getNumberOfUser(Integer.parseInt(orderId.getText().toString()));
                    star.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if(userDataDAO.getPaticularStar(numberOfUser) == 1)
                            {
                                recentDataObj.setSelected(false);
                                star.setBackgroundResource(R.drawable.ic_star_deactive);
                                userDataDAO.updateStar(0,numberOfUser);
                            }
                            else
                            {
                                recentDataObj.setSelected(true);
                                star.setBackgroundResource(R.drawable.ic_star_active);
                                userDataDAO.updateStar(1,numberOfUser);
                            }
                        }
                    });
                }
            });
        }

    }
    public void sortedList(List<RecentData> sortedList) {                       // SEARCH
        list = sortedList;
        this.notifyDataSetChanged();
    }
}
