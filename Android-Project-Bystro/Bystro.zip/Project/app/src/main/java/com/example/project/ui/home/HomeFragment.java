package com.example.project.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.example.project.OrderSummary;
import com.example.project.R;

public class HomeFragment extends Fragment {

    private GridView gridView;
    String canWaterName[] = {"Bisleri","Aqua Gold","Kinley","a","b","c","d"};
    String canWaterPrice[] = {"90","45","110","10","20","30","40"};
    int canWaterImage[] = {R.drawable.canwater,R.drawable.canwater,R.drawable.canwater,R.drawable.canwater,R.drawable.canwater,R.drawable.canwater,R.drawable.canwater};
    public View onCreateView(@NonNull LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        gridView = root.findViewById(R.id.gridview);
        CustomAdapter customAdapter = new CustomAdapter();
        gridView.setAdapter(customAdapter);
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(view.getId() == R.id.buyButton) {
                    Intent intent = new Intent(getActivity(), OrderSummary.class);
                    intent.putExtra("name", canWaterName[i]);
                    intent.putExtra("price", canWaterPrice[i]);
                    intent.putExtra("image", canWaterImage[i]);
                    startActivity(intent);
                }
            }
        });
        return root;
    }
    public class CustomAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return canWaterImage.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(final int position, View convertView, final ViewGroup parent) {
            View view1 = getLayoutInflater().inflate(R.layout.row_data,null);
            //getting view in row_data
            final TextView name = view1.findViewById(R.id.canwaterName);
            final TextView price = view1.findViewById(R.id.canwaterPrice);
            final ImageView image = view1.findViewById(R.id.images);
            name.setText(canWaterName[position]);
            price.setText(canWaterPrice[position]);
            image.setImageResource(canWaterImage[position]);
            final Button buy = view1.findViewById(R.id.buyButton);
            buy.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ((GridView)parent).performItemClick(v,position,0);
                }
            });
            return view1;
        }

    }
}