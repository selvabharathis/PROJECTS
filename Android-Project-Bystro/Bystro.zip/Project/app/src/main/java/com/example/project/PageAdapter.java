package com.example.project;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class PageAdapter extends FragmentPagerAdapter
{
    private int numberOfTabs;
    private List<Fragment> fragmentList;

    public void addFragments(Fragment fragments){
        this.fragmentList.add(fragments);
    }

    public PageAdapter(@NonNull FragmentManager fm, int numberOfTabs) {
        super(fm);
        fragmentList = new ArrayList();
        this.numberOfTabs = numberOfTabs;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        return fragmentList.get(position);
    }

    @Override
    public int getCount() {
        return numberOfTabs;
    }

    @Override
    public int getItemPosition(@NonNull Object object) {
        return POSITION_NONE;
    }
}
