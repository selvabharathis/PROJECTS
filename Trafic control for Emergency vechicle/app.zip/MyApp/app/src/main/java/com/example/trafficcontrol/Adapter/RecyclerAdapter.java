package com.example.trafficcontrol.Adapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.trafficcontrol.Activity.Authentication;
import com.example.trafficcontrol.ModelClass.ConnectedDeviceModel;
import com.example.trafficcontrol.R;

import java.util.Collections;
import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder>
{
    private List<ConnectedDeviceModel> list = Collections.emptyList();
    private Context context;
    public RecyclerAdapter(List<ConnectedDeviceModel> list, Context context)
    {
        this.list = list;
        this.context = context;
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View photoView = inflater.inflate(R.layout.card_connected_device,parent,false);
        ViewHolder viewHolder = new ViewHolder(photoView);
        return viewHolder;
    }
    @Override
    public void onBindViewHolder(final ViewHolder viewHolder,final int position)
    {
        final ConnectedDeviceModel connectedDeviceModelObj = list.get(position);
        viewHolder.deviceName.setText(connectedDeviceModelObj.getDeviceName());
    }
    @Override
    public int getItemCount()
    {
        return list.size();
    }
    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView)
    {
        super.onAttachedToRecyclerView(recyclerView);
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
       private Button select;
       private TextView deviceName;
        ViewHolder(final View itemView)
        {
            super(itemView);
            select = itemView.findViewById(R.id.selectButton);
            deviceName = itemView.findViewById(R.id.deviceNameTextView);
            context = itemView.getContext();
                select.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent goToAuth = new Intent(context, Authentication.class);
                        ConnectedDeviceModel connectedDeviceModelObj = list.get(getAdapterPosition());
                        if(connectedDeviceModelObj.getDeviceName().equals("ambulance"))
                        {
                            goToAuth.putExtra("deviceName",connectedDeviceModelObj.getDeviceName());
                            goToAuth.putExtra("deviceMac",connectedDeviceModelObj.getMacID());
                            context.startActivity(goToAuth);
                            ((Activity)itemView.getContext()).finish();// activity not getting finish
                        }
                        else
                        {
                            AlertDialog.Builder builder = new AlertDialog.Builder(itemView.getRootView().getContext());
                            builder.setTitle("INVALID CHOICE")
                                    .setMessage("the bluetooth device you have chosen is invalid, please select the kit's bluetooth i.e named as  \"ambulance\"")
                                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {

                                        }
                                    });
                            AlertDialog alertDialog = builder.create();
                            alertDialog.show();
                        }
                    }
                });
        }
    }
}
