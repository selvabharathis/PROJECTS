package com.example.trafficcontrol.ModelClass;

public class ConnectedDeviceModel {
    private String deviceName,macID;
    public ConnectedDeviceModel(String deviceName,String macID){
        this.deviceName = deviceName;
        this.macID = macID;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public String getMacID() {
        return macID;
    }
}
