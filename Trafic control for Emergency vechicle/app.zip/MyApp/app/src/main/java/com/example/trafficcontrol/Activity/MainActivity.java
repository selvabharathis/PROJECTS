package com.example.trafficcontrol.Activity;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;

import com.example.trafficcontrol.ModelClass.Bluetooth;
import com.example.trafficcontrol.R;

import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;

import static java.lang.Thread.currentThread;
import static java.lang.Thread.sleep;

@SuppressLint("NewApi")
public class MainActivity extends AppCompatActivity implements View.OnClickListener, SensorEventListener{
    int n, s, e, w;
    Button north, south, east, west, exit;
    private ImageView compassImage;
    private float[] gravity = new float[3];
    private float[] geomagnetic = new float[3];
    private float azimuth = 0f;
    private float currentAzimuth = 0f;
    private SensorManager sensorManager;
    Bluetooth myBluetooth;
    private boolean stopBackgroundThread = true;
    private String prevSignalData = "";
    Handler updateUI;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        north.setOnClickListener(this);
        south.setOnClickListener(this);
        east.setOnClickListener(this);
        west.setOnClickListener(this);
        exit.setOnClickListener(this);
        myBluetooth = new Bluetooth();
        myBluetooth.connectToBluetooth();
        myBluetooth.openStreamInputOutput();
        updateUI = new Handler(getApplicationContext().getMainLooper());

            new Thread(new Runnable() {
                @Override
                public void run() {
                    while(stopBackgroundThread) {
                        try {
                            String signalDataInJson = "";
                            signalDataInJson = myBluetooth.readJsonStringData();
                            System.out.println("signal data in json formate = " + signalDataInJson);
                            if (!prevSignalData.equals(signalDataInJson)) {
                                addToMessageQueue(signalDataInJson);
                                prevSignalData = signalDataInJson;
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        try {
                            currentThread().sleep(1000);
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            }).start();
    }

    private void init() {
        north = findViewById(R.id.north);
        south = findViewById(R.id.south);
        east = findViewById(R.id.east);
        west = findViewById(R.id.west);
        exit = findViewById(R.id.exit);
        n = 0;
        s = 0;
        e = 0;
        w = 0;
        north.setEnabled(false);
        south.setEnabled(false);
        east.setEnabled(false);
        west.setEnabled(false);
        compassImage = findViewById(R.id.compass);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
    }

    public void addToMessageQueue(final String sigData){
        updateUI.post(new Runnable()
        {
            @Override
            public void run() {
                try {
                    updateButtonAsPerSignal(sigData);
                } catch (JSONException ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    private void updateButtonAsPerSignal(final String sigData) throws JSONException {
        JSONObject jsonObject = new JSONObject(sigData);
        n = jsonObject.getInt("north");
        s = jsonObject.getInt("south");
        e = jsonObject.getInt("east");
        w = jsonObject.getInt("west");
        if(n==1){
            north.setEnabled(true);
            north.setBackgroundResource(R.color.green);
        }
        if(s==1){
            south.setEnabled(true);
            south.setBackgroundResource(R.color.green);
        }
        if(e==1){
            east.setEnabled(true);
            east.setBackgroundResource(R.color.green);
        }
        if(w==1){
            west.setEnabled(true);
            west.setBackgroundResource(R.color.green);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.north:
                Toast.makeText(MainActivity.this, "NORTH", Toast.LENGTH_SHORT).show();
                try {
                    myBluetooth.sendString("NORTH");
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                break;
            case R.id.south:
                Toast.makeText(MainActivity.this, "SOUTH", Toast.LENGTH_SHORT).show();
                try {
                    myBluetooth.sendString("SOUTH");
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                break;
            case R.id.east:
                Toast.makeText(MainActivity.this, "EAST", Toast.LENGTH_SHORT).show();
                try {
                    myBluetooth.sendString("EAST");
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                break;
            case R.id.west:
                Toast.makeText(MainActivity.this, "WEST", Toast.LENGTH_SHORT).show();
                try {
                    myBluetooth.sendString("WEST");
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                break;
            case R.id.exit:
                stopBackgroundThread = false;
                try {
                    sleep(2000);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
                try {
                    myBluetooth.closeBluetooth();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                finish();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener((SensorEventListener) this, sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD), SensorManager.SENSOR_DELAY_GAME);
        sensorManager.registerListener((SensorEventListener) this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener((SensorEventListener) this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        final float alpha = 0.97f;
        synchronized (this) {
            if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0];
                gravity[1] = alpha * gravity[1] + (1 - alpha) * event.values[1];
                gravity[2] = alpha * gravity[2] + (1 - alpha) * event.values[2];
            }
            if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
                geomagnetic[0] = alpha * geomagnetic[0] + (1 - alpha) * event.values[0];
                geomagnetic[1] = alpha * geomagnetic[1] + (1 - alpha) * event.values[1];
                geomagnetic[2] = alpha * geomagnetic[2] + (1 - alpha) * event.values[2];
            }
            float R[] = new float[9];
            float I[] = new float[9];
            boolean success = SensorManager.getRotationMatrix(R, I, gravity, geomagnetic);
            if (success) {
                float orientation[] = new float[3];
                SensorManager.getOrientation(R, orientation);
                azimuth = (float) Math.toDegrees(orientation[0]);
                azimuth = (azimuth + 360) % 360;
                Animation animae = new RotateAnimation(-currentAzimuth, -azimuth, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
                currentAzimuth = azimuth;
                animae.setDuration(500);
                animae.setRepeatCount(0);
                animae.setFillAfter(true);
                compassImage.startAnimation(animae);
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

}
