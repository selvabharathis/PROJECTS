package com.example.trafficcontrol.Activity;


import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import com.example.trafficcontrol.ModelClass.Bluetooth;
import com.example.trafficcontrol.R;
import java.io.IOException;

public class Authentication extends AppCompatActivity {
    private ImageView permissionImage;
    private Button permissionButton;
    String macId,deviceName;
    Handler handlerOne,handlerTwo;
    Runnable runnable;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authentication);
        permissionImage = findViewById(R.id.permissionImage);
        permissionButton = findViewById(R.id.permissionButton);
        Intent get = getIntent();
        deviceName = get.getStringExtra("deviceName");
        macId = get.getStringExtra("deviceMac");
        System.out.println(deviceName+"  "+macId);
        final Bluetooth myBluetooth = new Bluetooth();
        myBluetooth.connectToBluetooth();
        myBluetooth.openStreamInputOutput();
        handlerOne = new Handler(getApplicationContext().getMainLooper());// UI thread
        handlerTwo = new Handler();// background thread
        runnable = new Runnable() {
            @Override
            public void run() {
                while(true){
                    try {
                        char abc = myBluetooth.readAChar();
                        if(abc== 'y')
                        {
                            System.out.println("came inside if condition");
                            handlerTwo.removeCallbacks(runnable);// once my background thread(handlerTwo--runnable) received a char, i stop that thread.
                            handlerOne.post(new Runnable() {
                                @Override
                                public void run() {
                                    permissionButton.setBackgroundResource(R.drawable.button_green);
                                    permissionImage.setBackgroundResource(R.drawable.allow_in);
                                    permissionImage.setVisibility(View.VISIBLE);
                                    permissionButton.setVisibility(View.VISIBLE);
                                    permissionImage.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent goToConnectedDevice = new Intent(Authentication.this,MainActivity.class);
                                            startActivity(goToConnectedDevice);
                                            finish();
                                        }
                                    });
                                    try {
                                        myBluetooth.closeBluetooth();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }
                            });
                            break;// break the while once the char is received...
                        }
                        else if(abc == 'n')
                        {
                            System.out.println("came inside else if condition");
                            handlerTwo.removeCallbacks(runnable);// once my background thread(handlerTwo--runnable) received a char, i stop that thread.
                            handlerOne.post(new Runnable() {
                                @Override
                                public void run() {
                                    permissionButton.setBackgroundResource(R.drawable.button_red);
                                    permissionButton.setText("UNAUTHORISED USER");
                                    permissionImage.setBackgroundResource(R.drawable.alert);
                                    permissionImage.setVisibility(View.VISIBLE);
                                    permissionButton.setVisibility(View.VISIBLE);
                                    final MediaPlayer mp = MediaPlayer.create(Authentication.this,R.raw.osmium);
                                    mp.start();
                                    SmsManager smsManager = SmsManager.getDefault();
                                    smsManager.sendTextMessage("6385120999",null,"!!! ALERT  !! Unauthorised access to ambulance",null,null);
                                    try {
                                        myBluetooth.closeBluetooth();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }
                            });

                            break;// break the while once the char is received...
                        }

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        };
        handlerTwo.postDelayed(runnable,5000);
    }
}
