package com.example.trafficcontrol.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.os.Bundle;
import com.example.trafficcontrol.Adapter.RecyclerAdapter;
import com.example.trafficcontrol.ModelClass.ConnectedDeviceModel;
import com.example.trafficcontrol.R;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class ConnectedDevice extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RecyclerAdapter recyclerAdapter;
    private List<ConnectedDeviceModel> listOfObject;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connected_device);
        recyclerView = findViewById(R.id.recyclerView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        listOfObject = new ArrayList<>();
        recyclerAdapter = new RecyclerAdapter(listOfObject,getApplicationContext());
        recyclerView.setAdapter(recyclerAdapter);
        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        if (pairedDevices.size() > 0)
        {
            // There are paired devices. Get the name and address of each paired device.
            for (BluetoothDevice device : pairedDevices) {
                String deviceName = device.getName();
                String deviceHardwareAddress = device.getAddress(); // MAC address
                ConnectedDeviceModel data = new ConnectedDeviceModel(deviceName,deviceHardwareAddress);
                listOfObject.add(listOfObject.size(), data);
                recyclerAdapter.notifyDataSetChanged();
            }
        }

    }
}
