package com.example.trafficcontrol.Activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;

import com.example.trafficcontrol.R;

public class CheckBluetoothCondition extends AppCompatActivity {
    int REQUEST_ENABLE_BT = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_bluetooth_condition);
        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (!bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        }
        else
        {
            Intent goToAuth = new Intent(CheckBluetoothCondition.this,ConnectedDevice.class);
            startActivity(goToAuth);
            finish();
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_CANCELED){
            finish();
        }
        if(resultCode == RESULT_OK){
            Intent goToAuth = new Intent(CheckBluetoothCondition.this,ConnectedDevice.class);
            startActivity(goToAuth);
            finish();
        }
    }
}
