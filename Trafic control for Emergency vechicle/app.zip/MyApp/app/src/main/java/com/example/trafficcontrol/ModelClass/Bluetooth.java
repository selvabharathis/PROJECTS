package com.example.trafficcontrol.ModelClass;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.UUID;

public class Bluetooth {
    private BluetoothSocket bluetoothSocket;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothDevice hc05;
    private static final UUID mUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private OutputStream outputStream;
    private InputStream inputStream;

    @SuppressLint("NewApi")
    public void connectToBluetooth(){
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        hc05 = bluetoothAdapter.getRemoteDevice("00:19:09:26:0C:A6");
        bluetoothSocket = null;
        int counter = 0;
        do{
            try {
                bluetoothSocket = hc05.createRfcommSocketToServiceRecord(mUUID);
                bluetoothSocket.connect();
            } catch (IOException e) {
                e.printStackTrace();
            }
            counter++;
        }while (!bluetoothSocket.isConnected() && counter<3);
    }

    @SuppressLint("NewApi")
    public void openStreamInputOutput(){
        try {
            outputStream = bluetoothSocket.getOutputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            inputStream = bluetoothSocket.getInputStream();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public char readAChar() throws IOException{
        inputStream.skip(inputStream.available());
        byte b = (byte)inputStream.read();
        System.out.println("bluetooth char received = "+(char)b);
        return (char)b;
    }

    public String readJsonStringData() throws IOException {
        int bufferSize =1024;
        byte[] buffer = new byte[bufferSize];
        outputStream.write('j');
        int lengthOfString = inputStream.read(buffer);
        System.out.println("bluetooth string length = "+lengthOfString);
        String data = new String(buffer,0,lengthOfString);
        System.out.println("bluetooth string received = "+data);
        return data;
    }

    @SuppressLint("NewApi")
    public void sendString(String userRequest) throws IOException {
        System.out.println("writing these bytes to arduino = "+userRequest.getBytes(Charset.forName("UTF-8")));
        outputStream.write(userRequest.getBytes(Charset.forName("UTF-8")));
    }

    public void closeBluetooth() throws IOException {
        bluetoothSocket.close();
    }
}
